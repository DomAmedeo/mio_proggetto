public class Prenotazione{
    private String nomeCliente;
    private String data;
    private int postiRichiesti;
    
    // Costruttore
    public Prenotazione(String nomeCliente, String data, int postiRichiesti){
        this.nomeCliente = nomeCliente;
        this.data = data;
        this.postiRichiesti = postiRichiesti;
    }

    // Metodo generale per la validaazione delle prenorazioni 
    public Boolean validaPrenotazione(int postiDisponibili){
        return false;
    };

    // Metodo che stampa tutti i dettagli della prenotazione
    public void stampaDettagli(){
        System.out.println("La prenotazione a nome: "+ nomeCliente + ";");
        System.out.println("La prenotazione in data: "+ data + ";");
        System.out.println("La prenotazione con posti richiesti: "+ postiRichiesti + ".");
    };

    // Metodi Set per tutti i campi
    public void setNome(String nome){
        // Sovrasscrive il vecchio nome (nomeCliente) con il nuovo nome
        nomeCliente = nome;
    }
    public void setData(String dataArrivata){
        data = dataArrivata;
    }
    public void setPostiRichiesti(int richiesta){
        postiRichiesti = richiesta;
    }

    // Metodi Get per tutti i campi
    public String getNome(){
        return nomeCliente;
    }

    public String getData(){
        return data;
    }

    public int getPostiRichiesti(){
        return postiRichiesti;
    }

}