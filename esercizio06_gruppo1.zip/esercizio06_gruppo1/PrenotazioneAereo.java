public class PrenotazioneAereo extends Prenotazione{

    private Boolean classe;
    
    //Costruttore
    public PrenotazioneAereo(String nomeCliente, String data, int postiRichiesti, boolean classe){
        super(nomeCliente, data, postiRichiesti);
        this.classe = classe;
    }

    @Override
    public Boolean validaPrenotazione(int postiDisponibili){
        int postiRichiesti2 = getPostiRichiesti();
        if(postiRichiesti2 <= postiDisponibili){
            if(classe == true){
                return postiRichiesti2 <= 150;
            }else if(classe == false){
                return postiRichiesti2 <= 25;
            }else{
                return false;
            }
        }else{
            return false;
        }
    }
}
