public class PrenotazioneConcerto extends Prenotazione{

    //Costruttore
    public PrenotazioneConcerto(String nomeCliente, String data, int postiRichiesti){
        super(nomeCliente, data, postiRichiesti);
    }

    @Override
    public Boolean validaPrenotazione(int postiDisponibili){
        int postiRichiesti2 = getPostiRichiesti();
        if(postiRichiesti2 <= postiDisponibili && postiRichiesti2 <= 5){
            return true;
        }else{
            return false;
        }
    }
}