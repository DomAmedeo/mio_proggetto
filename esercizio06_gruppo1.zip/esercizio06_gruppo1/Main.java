
import java.util.ArrayList; // Import the ArrayList class

public class Main {
    public static void main(String[] args) {
        // Prenotazione p1 = new Prenotazione("Pippo", "20-10-2025", 24);
        PrenotazioneConcerto p2 = new PrenotazioneConcerto("Pippo", "20-10-2025", 5);
        // PrenotazioneAereo p3 = new PrenotazioneAereo("Pippo", "20-10-2025", 24, false);
        
        ArrayList<Prenotazione> listaPrenotazioni = new ArrayList<>(); 
        listaPrenotazioni.add(new PrenotazioneConcerto("Mario Rossi", "2025-09-01", 3));
        listaPrenotazioni.add(new PrenotazioneConcerto("Lucia Verdi", "2025-09-01", 6)); 
        listaPrenotazioni.add(new PrenotazioneAereo("Gianni Bianchi", "2025-09-05", 2, false));
        listaPrenotazioni.add(new PrenotazioneAereo("Anna Neri", "2025-09-05", 60, false)); 
        listaPrenotazioni.add(new PrenotazioneAereo("Paolo Gialli", "2025-09-05", 45, true));

        int contare;
        for (Prenotazione p : listaPrenotazioni) {
            contare = p.length();
            System.out.printl(contare);
        }



        // // p1.stampaDettagli();
        // // p1.setNome("Antonio");
        // // p1.setData("10-10-1010");
        // // p1.setPostiRichiesti(4);
        // // p1.stampaDettagli();
        // // String data = p1.getData();
        // // String nome = p1.getNome();
        // // int posti = p1.getPostiRichiesti();

        // boolean valida = p2.validaPrenotazione(175);
        // // boolean valida = p3.validaPrenotazione(175);

        // System.out.println("data + nome + posti " + valida);

    }


}